import unittest

from camcommand.acs200_protocol import parse_response_lines, status_code_meaning


class TestAcs200Protocol(unittest.TestCase):
    def test_parse_leading_status_with_payload(self) -> None:
        parsed = parse_response_lines(["6", "State,0,0,1"])
        self.assertEqual(parsed.status_code, 6)
        self.assertEqual(parsed.payload_lines, ["State,0,0,1"])
        self.assertEqual(parsed.raw_lines, ["6", "State,0,0,1"])

    def test_does_not_treat_single_numeric_line_as_status(self) -> None:
        parsed = parse_response_lines(["123"])
        self.assertIsNone(parsed.status_code)
        self.assertEqual(parsed.payload_lines, ["123"])

    def test_treats_known_single_code_as_status(self) -> None:
        parsed = parse_response_lines(["0"])
        self.assertEqual(parsed.status_code, 0)
        self.assertEqual(parsed.payload_lines, [])

    def test_does_not_treat_numeric_payload_as_status(self) -> None:
        parsed = parse_response_lines(["6", "7"])
        self.assertIsNone(parsed.status_code)
        self.assertEqual(parsed.payload_lines, ["6", "7"])

    def test_known_status_meanings(self) -> None:
        self.assertEqual(status_code_meaning(0), "ok")
        self.assertEqual(status_code_meaning(6), "intrusion alarm")
        self.assertEqual(status_code_meaning(999), "unknown")


if __name__ == "__main__":
    unittest.main()
